import random
from time import strftime
from system.core.controller import *

class Gold(Controller):
    def __init__(self, action):
        super(Gold, self).__init__(action)
        self.load_model('WelcomeModel')
        self.db = self._app.db

    def index(self):
        print "ln 10: good hit"
        if session.get('gold')==None:
            session['gold']=0
        if session.get('activity')==None:
            session['activity']=[]
        return self.load_view('index.html')

    def gold(self):
        gold=None
        if request.form['building']=='farm':
            print "line 18: hit farm"
            gold=random.randrange(10,21)
        elif request.form['building']=='cave':
            print "line 22: hit cave"
            gold=random.randrange(5,11)
        elif request.form['building']=='house':
            print "line 26: hit house"
            gold=random.randrange(2,6)
        elif request.form['building']=='casino':
            print "line 30: hit casino"
            gold=random.randrange(-50,51)
        session['gold']+=gold
        session['activity'].append("Earned {} from the {}".format(gold, request.form['building']))
        return redirect('/')




    def reset(self):
        print 'reset'
        session.clear()
        return redirect('/')
