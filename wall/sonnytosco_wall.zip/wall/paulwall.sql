INSERT INTO comments (message_id,user_id, comment, created_at, updated_at)
                VALUES (3, 1, 'testcomment', NOW(), NOW())