import random
import string
from system.core.controller import *

key_len=14

class Welcome(Controller):
    def __init__(self, action):
        super(Welcome, self).__init__(action)
    def index(self):
        print "g2g"
        if session.get('count')==None:
            session['count']=0
        session['count']=session['count']+1
        rand =''
        print 'process route hit'
        rand = ''.join([random.choice(string.letters+string.digits) for i in range(key_len)])
        return self.load_view('index.html', rand=rand)
    def process(self):
        return redirect('/')
