from flask import Flask, render_template, redirect, request, session, flash
# the "re" module will let us perform some regular expression operations
import re
# create a regular expression object that we can use run operations on
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
app = Flask(__name__)
app.secret_key = "ThisIsSecret!"
@app.route('/', methods=['GET'])
def index():
    print "g2g"
    return render_template("index.html")
@app.route('/friends', methods=['POST'])
def submit():
    data=request.form
    print "Gucci"
    if len(data['email']) < 1:
        flash("Email cannot be blank!")
    elif not EMAIL_REGEX.match(data['email']):
        flash("Invalid Email Address!")
    else:
        flash("Success!")
    print "Carter4"
    return redirect('/')
app.run(debug=True)
