from system.core.controller import *

class Welcome(Controller):
    def __init__(self, action):
        super (Welcome, self).__init__(action)
    def index(self):
        return self.load_view('index.html')
    def create (self):
        print "test"
        if session.get('count')==None:
            session['count']=0
        session['count']=session['count']+1
        data = request.form
        if len(request.form['name']) < 1:
            flash("Name cannot be empty!")
        elif len(request.form['comments']) > 120:
            flash("You talk too much. Shorten your comment")
        elif len(request.form['name']) > 1:
            flash("Success! Your name is {}".format(request.form['name']))
        print data
        return self.load_view('/result.html', data=data)
